package com.cg.mobilebilling.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.responses.CustomResponse;

@ControllerAdvice
public class BillingExceptionAspect {
	@ExceptionHandler(BillDetailsNotFoundException.class)
	public ResponseEntity<CustomResponse> handleBillDetailsNotFoundException(Exception e) {
		CustomResponse response= new CustomResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(BillingServicesDownException.class)
	public ResponseEntity<CustomResponse> handleBillingServicesDownException(Exception e) {
		CustomResponse response= new CustomResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(CustomerDetailsNotFoundException.class)
	public ResponseEntity<CustomResponse> handleCustomerDetailsNotFoundException(Exception e) {
		CustomResponse response= new CustomResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(InvalidBillMonthException.class)
	public ResponseEntity<CustomResponse> handleInvalidBillMonthException(Exception e) {
		CustomResponse response= new CustomResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(PlanDetailsNotFoundException.class)
	public ResponseEntity<CustomResponse> handlePlanDetailsNotFoundException(Exception e) {
		CustomResponse response= new CustomResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(PostpaidAccountNotFoundException.class)
	public ResponseEntity<CustomResponse> handlePostpaidAccountNotFoundException(Exception e) {
		CustomResponse response= new CustomResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
}