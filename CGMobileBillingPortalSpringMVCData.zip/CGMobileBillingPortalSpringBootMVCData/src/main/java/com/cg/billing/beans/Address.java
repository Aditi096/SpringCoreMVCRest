package com.cg.billing.beans;
import javax.persistence.Embeddable;
@Embeddable
public class Address {
	private String homeAddresscity, homeAddressState;
	private int homePinCode;
	private String billingAddresscity, billingAddressState;
	private int billingPinCode;
	public Address() {}
	public Address(String homeAddresscity, String homeAddresSstate, int homePinCode, String billingAddresscity,
			String billingAddresSstate, int billingPinCode) {
		super();
		this.homeAddresscity = homeAddresscity;
		this.homeAddressState = homeAddresSstate;
		this.homePinCode = homePinCode;
		this.billingAddresscity = billingAddresscity;
		this.billingAddressState = billingAddresSstate;
		this.billingPinCode = billingPinCode;
	}
	public String getHomeAddresscity() {
		return homeAddresscity;
	}
	public void setHomeAddresscity(String homeAddresscity) {
		this.homeAddresscity = homeAddresscity;
	}
	public String getHomeAddressState() {
		return homeAddressState;
	}
	public void setHomeAddressState(String homeAddresSstate) {
		this.homeAddressState = homeAddresSstate;
	}
	public int getHomePinCode() {
		return homePinCode;
	}
	public void setHomePinCode(int homePinCode) {
		this.homePinCode = homePinCode;
	}
	public String getBillingAddresscity() {
		return billingAddresscity;
	}
	public void setBillingAddresscity(String billingAddresscity) {
		this.billingAddresscity = billingAddresscity;
	}
	public String getBillingAddressState() {
		return billingAddressState;
	}
	public void setBillingAddressState(String billingAddresSstate) {
		this.billingAddressState = billingAddresSstate;
	}
	public int getBillingPinCode() {
		return billingPinCode;
	}
	public void setBillingPinCode(int billingPinCode) {
		this.billingPinCode = billingPinCode;
	}
	@Override
	public String toString() {
		return "Address [homeAddresscity=" + homeAddresscity + ", homeAddresSstate=" + homeAddressState
				+ ", homePinCode=" + homePinCode + ", billingAddresscity=" + billingAddresscity
				+ ", billingAddresSstate=" + billingAddressState + ", billingPinCode=" + billingPinCode + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((billingAddressState == null) ? 0 : billingAddressState.hashCode());
		result = prime * result + ((billingAddresscity == null) ? 0 : billingAddresscity.hashCode());
		result = prime * result + billingPinCode;
		result = prime * result + ((homeAddressState == null) ? 0 : homeAddressState.hashCode());
		result = prime * result + ((homeAddresscity == null) ? 0 : homeAddresscity.hashCode());
		result = prime * result + homePinCode;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (billingAddressState == null) {
			if (other.billingAddressState != null)
				return false;
		} else if (!billingAddressState.equals(other.billingAddressState))
			return false;
		if (billingAddresscity == null) {
			if (other.billingAddresscity != null)
				return false;
		} else if (!billingAddresscity.equals(other.billingAddresscity))
			return false;
		if (billingPinCode != other.billingPinCode)
			return false;
		if (homeAddressState == null) {
			if (other.homeAddressState != null)
				return false;
		} else if (!homeAddressState.equals(other.homeAddressState))
			return false;
		if (homeAddresscity == null) {
			if (other.homeAddresscity != null)
				return false;
		} else if (!homeAddresscity.equals(other.homeAddresscity))
			return false;
		if (homePinCode != other.homePinCode)
			return false;
		return true;
	}
	
}